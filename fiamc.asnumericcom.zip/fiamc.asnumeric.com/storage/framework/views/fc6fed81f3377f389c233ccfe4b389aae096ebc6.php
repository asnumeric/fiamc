
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH /home/stebio/Workstation/www/Clients/fiamc.asnumeric.com/resources/views/admin/content.blade.php ENDPATH**/ ?>